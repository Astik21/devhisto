<?php
define('DB_HOST', 'localhost');
define('DB_PORT', '');
define('DB_NAME', 'devhisto');
define('DB_USER', 'devhisto');
define('DB_PASSWORD', 'devhisto');